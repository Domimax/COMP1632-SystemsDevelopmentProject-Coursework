﻿namespace SystemsDevProject
{
    partial class SeatPlan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Booking = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.A4 = new System.Windows.Forms.Button();
            this.A5 = new System.Windows.Forms.Button();
            this.A6 = new System.Windows.Forms.Button();
            this.A10 = new System.Windows.Forms.Button();
            this.A11 = new System.Windows.Forms.Button();
            this.A12 = new System.Windows.Forms.Button();
            this.A16 = new System.Windows.Forms.Button();
            this.A17 = new System.Windows.Forms.Button();
            this.A18 = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.B8 = new System.Windows.Forms.Button();
            this.B9 = new System.Windows.Forms.Button();
            this.B10 = new System.Windows.Forms.Button();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.C17 = new System.Windows.Forms.Button();
            this.C18 = new System.Windows.Forms.Button();
            this.flowLayoutPanelB = new System.Windows.Forms.FlowLayoutPanel();
            this.B1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.C15 = new System.Windows.Forms.Button();
            this.C16 = new System.Windows.Forms.Button();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.A1 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A7 = new System.Windows.Forms.Button();
            this.A8 = new System.Windows.Forms.Button();
            this.A9 = new System.Windows.Forms.Button();
            this.A13 = new System.Windows.Forms.Button();
            this.A14 = new System.Windows.Forms.Button();
            this.A15 = new System.Windows.Forms.Button();
            this.flowLayoutPanelC = new System.Windows.Forms.FlowLayoutPanel();
            this.C1 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C3 = new System.Windows.Forms.Button();
            this.C4 = new System.Windows.Forms.Button();
            this.C5 = new System.Windows.Forms.Button();
            this.C6 = new System.Windows.Forms.Button();
            this.C7 = new System.Windows.Forms.Button();
            this.C8 = new System.Windows.Forms.Button();
            this.C9 = new System.Windows.Forms.Button();
            this.C10 = new System.Windows.Forms.Button();
            this.C11 = new System.Windows.Forms.Button();
            this.C12 = new System.Windows.Forms.Button();
            this.C13 = new System.Windows.Forms.Button();
            this.C14 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanelB.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanelC.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(502, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 29);
            this.label1.TabIndex = 30;
            this.label1.Text = "Seat Selection";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Booking);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.flowLayoutPanel2);
            this.panel1.Controls.Add(this.flowLayoutPanel5);
            this.panel1.Controls.Add(this.flowLayoutPanelB);
            this.panel1.Controls.Add(this.flowLayoutPanel3);
            this.panel1.Controls.Add(this.flowLayoutPanel4);
            this.panel1.Controls.Add(this.flowLayoutPanelC);
            this.panel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(266, 51);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(637, 511);
            this.panel1.TabIndex = 31;
            // 
            // Booking
            // 
            this.Booking.Location = new System.Drawing.Point(215, 469);
            this.Booking.Margin = new System.Windows.Forms.Padding(4);
            this.Booking.Name = "Booking";
            this.Booking.Size = new System.Drawing.Size(179, 37);
            this.Booking.TabIndex = 37;
            this.Booking.Text = "Confirm tickets for the selected seats";
            this.Booking.UseVisualStyleBackColor = true;
            this.Booking.Click += new System.EventHandler(this.Booking_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(55, 412);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(481, 48);
            this.button1.TabIndex = 36;
            this.button1.Text = "Stage";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.flowLayoutPanel1.Controls.Add(this.A4);
            this.flowLayoutPanel1.Controls.Add(this.A5);
            this.flowLayoutPanel1.Controls.Add(this.A6);
            this.flowLayoutPanel1.Controls.Add(this.A10);
            this.flowLayoutPanel1.Controls.Add(this.A11);
            this.flowLayoutPanel1.Controls.Add(this.A12);
            this.flowLayoutPanel1.Controls.Add(this.A16);
            this.flowLayoutPanel1.Controls.Add(this.A17);
            this.flowLayoutPanel1.Controls.Add(this.A18);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(350, 244);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(273, 160);
            this.flowLayoutPanel1.TabIndex = 31;
            // 
            // A4
            // 
            this.A4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(4, 4);
            this.A4.Margin = new System.Windows.Forms.Padding(4);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(80, 43);
            this.A4.TabIndex = 16;
            this.A4.Text = "A\r\n4";
            this.A4.UseVisualStyleBackColor = true;
            // 
            // A5
            // 
            this.A5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(92, 4);
            this.A5.Margin = new System.Windows.Forms.Padding(4);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(80, 43);
            this.A5.TabIndex = 17;
            this.A5.Text = "A\r\n5";
            this.A5.UseVisualStyleBackColor = true;
            // 
            // A6
            // 
            this.A6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.Location = new System.Drawing.Point(180, 4);
            this.A6.Margin = new System.Windows.Forms.Padding(4);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(80, 43);
            this.A6.TabIndex = 18;
            this.A6.Text = "A\r\n6";
            this.A6.UseVisualStyleBackColor = true;
            // 
            // A10
            // 
            this.A10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A10.Location = new System.Drawing.Point(4, 55);
            this.A10.Margin = new System.Windows.Forms.Padding(4);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(80, 43);
            this.A10.TabIndex = 19;
            this.A10.Text = "A\r\n10";
            this.A10.UseVisualStyleBackColor = true;
            // 
            // A11
            // 
            this.A11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A11.Location = new System.Drawing.Point(92, 55);
            this.A11.Margin = new System.Windows.Forms.Padding(4);
            this.A11.Name = "A11";
            this.A11.Size = new System.Drawing.Size(80, 43);
            this.A11.TabIndex = 20;
            this.A11.Text = "A\r11";
            this.A11.UseVisualStyleBackColor = true;
            // 
            // A12
            // 
            this.A12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A12.Location = new System.Drawing.Point(180, 55);
            this.A12.Margin = new System.Windows.Forms.Padding(4);
            this.A12.Name = "A12";
            this.A12.Size = new System.Drawing.Size(80, 43);
            this.A12.TabIndex = 21;
            this.A12.Text = "A\r\n12";
            this.A12.UseVisualStyleBackColor = true;
            // 
            // A16
            // 
            this.A16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A16.Location = new System.Drawing.Point(4, 106);
            this.A16.Margin = new System.Windows.Forms.Padding(4);
            this.A16.Name = "A16";
            this.A16.Size = new System.Drawing.Size(80, 43);
            this.A16.TabIndex = 22;
            this.A16.Text = "A\r16";
            this.A16.UseVisualStyleBackColor = true;
            // 
            // A17
            // 
            this.A17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A17.Location = new System.Drawing.Point(92, 106);
            this.A17.Margin = new System.Windows.Forms.Padding(4);
            this.A17.Name = "A17";
            this.A17.Size = new System.Drawing.Size(80, 43);
            this.A17.TabIndex = 23;
            this.A17.Text = "A\r\n17";
            this.A17.UseVisualStyleBackColor = true;
            // 
            // A18
            // 
            this.A18.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A18.Location = new System.Drawing.Point(180, 106);
            this.A18.Margin = new System.Windows.Forms.Padding(4);
            this.A18.Name = "A18";
            this.A18.Size = new System.Drawing.Size(80, 43);
            this.A18.TabIndex = 24;
            this.A18.Text = "A\r\n18";
            this.A18.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.Yellow;
            this.flowLayoutPanel2.Controls.Add(this.B8);
            this.flowLayoutPanel2.Controls.Add(this.B9);
            this.flowLayoutPanel2.Controls.Add(this.B10);
            this.flowLayoutPanel2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel2.Location = new System.Drawing.Point(184, 123);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(264, 55);
            this.flowLayoutPanel2.TabIndex = 33;
            // 
            // B8
            // 
            this.B8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.Location = new System.Drawing.Point(4, 4);
            this.B8.Margin = new System.Windows.Forms.Padding(4);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(80, 43);
            this.B8.TabIndex = 27;
            this.B8.Text = "B\r\n8";
            this.B8.UseVisualStyleBackColor = true;
            // 
            // B9
            // 
            this.B9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B9.Location = new System.Drawing.Point(92, 4);
            this.B9.Margin = new System.Windows.Forms.Padding(4);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(80, 43);
            this.B9.TabIndex = 28;
            this.B9.Text = "B\r\n9";
            this.B9.UseVisualStyleBackColor = true;
            // 
            // B10
            // 
            this.B10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B10.Location = new System.Drawing.Point(180, 4);
            this.B10.Margin = new System.Windows.Forms.Padding(4);
            this.B10.Name = "B10";
            this.B10.Size = new System.Drawing.Size(80, 43);
            this.B10.TabIndex = 29;
            this.B10.Text = "B\r\n10";
            this.B10.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.flowLayoutPanel5.Controls.Add(this.C17);
            this.flowLayoutPanel5.Controls.Add(this.C18);
            this.flowLayoutPanel5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel5.Location = new System.Drawing.Point(452, 123);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(176, 55);
            this.flowLayoutPanel5.TabIndex = 35;
            // 
            // C17
            // 
            this.C17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C17.Location = new System.Drawing.Point(4, 4);
            this.C17.Margin = new System.Windows.Forms.Padding(4);
            this.C17.Name = "C17";
            this.C17.Size = new System.Drawing.Size(80, 43);
            this.C17.TabIndex = 25;
            this.C17.Text = "C\r\n17";
            this.C17.UseVisualStyleBackColor = true;
            // 
            // C18
            // 
            this.C18.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C18.Location = new System.Drawing.Point(92, 4);
            this.C18.Margin = new System.Windows.Forms.Padding(4);
            this.C18.Name = "C18";
            this.C18.Size = new System.Drawing.Size(80, 43);
            this.C18.TabIndex = 26;
            this.C18.Text = "C\r\n18";
            this.C18.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanelB
            // 
            this.flowLayoutPanelB.BackColor = System.Drawing.Color.Yellow;
            this.flowLayoutPanelB.Controls.Add(this.B1);
            this.flowLayoutPanelB.Controls.Add(this.B2);
            this.flowLayoutPanelB.Controls.Add(this.B3);
            this.flowLayoutPanelB.Controls.Add(this.B4);
            this.flowLayoutPanelB.Controls.Add(this.B5);
            this.flowLayoutPanelB.Controls.Add(this.B6);
            this.flowLayoutPanelB.Controls.Add(this.B7);
            this.flowLayoutPanelB.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanelB.Location = new System.Drawing.Point(4, 182);
            this.flowLayoutPanelB.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanelB.Name = "flowLayoutPanelB";
            this.flowLayoutPanelB.Size = new System.Drawing.Size(619, 54);
            this.flowLayoutPanelB.TabIndex = 30;
            // 
            // B1
            // 
            this.B1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(4, 4);
            this.B1.Margin = new System.Windows.Forms.Padding(4);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(80, 43);
            this.B1.TabIndex = 15;
            this.B1.Text = "B\r\n1";
            this.B1.UseVisualStyleBackColor = true;
            // 
            // B2
            // 
            this.B2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(92, 4);
            this.B2.Margin = new System.Windows.Forms.Padding(4);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(80, 43);
            this.B2.TabIndex = 16;
            this.B2.Text = "B\r\n2";
            this.B2.UseVisualStyleBackColor = true;
            // 
            // B3
            // 
            this.B3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(180, 4);
            this.B3.Margin = new System.Windows.Forms.Padding(4);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(80, 43);
            this.B3.TabIndex = 17;
            this.B3.Text = "B\r\n3";
            this.B3.UseVisualStyleBackColor = true;
            // 
            // B4
            // 
            this.B4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(268, 4);
            this.B4.Margin = new System.Windows.Forms.Padding(4);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(80, 43);
            this.B4.TabIndex = 18;
            this.B4.Text = "B\r\n4";
            this.B4.UseVisualStyleBackColor = true;
            // 
            // B5
            // 
            this.B5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(356, 4);
            this.B5.Margin = new System.Windows.Forms.Padding(4);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(80, 43);
            this.B5.TabIndex = 19;
            this.B5.Text = "B\r\n5";
            this.B5.UseVisualStyleBackColor = true;
            // 
            // B6
            // 
            this.B6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(444, 4);
            this.B6.Margin = new System.Windows.Forms.Padding(4);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(80, 43);
            this.B6.TabIndex = 20;
            this.B6.Text = "B\r\n6";
            this.B6.UseVisualStyleBackColor = true;
            // 
            // B7
            // 
            this.B7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(532, 4);
            this.B7.Margin = new System.Windows.Forms.Padding(4);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(80, 43);
            this.B7.TabIndex = 21;
            this.B7.Text = "B\r\n7";
            this.B7.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.flowLayoutPanel3.Controls.Add(this.C15);
            this.flowLayoutPanel3.Controls.Add(this.C16);
            this.flowLayoutPanel3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel3.Location = new System.Drawing.Point(4, 123);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(176, 55);
            this.flowLayoutPanel3.TabIndex = 34;
            // 
            // C15
            // 
            this.C15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C15.Location = new System.Drawing.Point(4, 4);
            this.C15.Margin = new System.Windows.Forms.Padding(4);
            this.C15.Name = "C15";
            this.C15.Size = new System.Drawing.Size(80, 43);
            this.C15.TabIndex = 25;
            this.C15.Text = "C\r\n15";
            this.C15.UseVisualStyleBackColor = true;
            // 
            // C16
            // 
            this.C16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C16.Location = new System.Drawing.Point(92, 4);
            this.C16.Margin = new System.Windows.Forms.Padding(4);
            this.C16.Name = "C16";
            this.C16.Size = new System.Drawing.Size(80, 43);
            this.C16.TabIndex = 26;
            this.C16.Text = "C\r\n16";
            this.C16.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.flowLayoutPanel4.Controls.Add(this.A1);
            this.flowLayoutPanel4.Controls.Add(this.A2);
            this.flowLayoutPanel4.Controls.Add(this.A3);
            this.flowLayoutPanel4.Controls.Add(this.A7);
            this.flowLayoutPanel4.Controls.Add(this.A8);
            this.flowLayoutPanel4.Controls.Add(this.A9);
            this.flowLayoutPanel4.Controls.Add(this.A13);
            this.flowLayoutPanel4.Controls.Add(this.A14);
            this.flowLayoutPanel4.Controls.Add(this.A15);
            this.flowLayoutPanel4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel4.Location = new System.Drawing.Point(4, 244);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(269, 160);
            this.flowLayoutPanel4.TabIndex = 32;
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(4, 4);
            this.A1.Margin = new System.Windows.Forms.Padding(4);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(80, 43);
            this.A1.TabIndex = 16;
            this.A1.Text = "A\r\n1";
            this.A1.UseVisualStyleBackColor = true;
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(92, 4);
            this.A2.Margin = new System.Windows.Forms.Padding(4);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(80, 43);
            this.A2.TabIndex = 17;
            this.A2.Text = "A\r\n2";
            this.A2.UseVisualStyleBackColor = true;
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(180, 4);
            this.A3.Margin = new System.Windows.Forms.Padding(4);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(80, 43);
            this.A3.TabIndex = 18;
            this.A3.Text = "A\r\n3";
            this.A3.UseVisualStyleBackColor = true;
            // 
            // A7
            // 
            this.A7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A7.Location = new System.Drawing.Point(4, 55);
            this.A7.Margin = new System.Windows.Forms.Padding(4);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(80, 43);
            this.A7.TabIndex = 19;
            this.A7.Text = "A\r\n7";
            this.A7.UseVisualStyleBackColor = true;
            // 
            // A8
            // 
            this.A8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A8.Location = new System.Drawing.Point(92, 55);
            this.A8.Margin = new System.Windows.Forms.Padding(4);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(80, 43);
            this.A8.TabIndex = 20;
            this.A8.Text = "A\r\n8";
            this.A8.UseVisualStyleBackColor = true;
            // 
            // A9
            // 
            this.A9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A9.Location = new System.Drawing.Point(180, 55);
            this.A9.Margin = new System.Windows.Forms.Padding(4);
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(80, 43);
            this.A9.TabIndex = 21;
            this.A9.Text = "A\r\n9";
            this.A9.UseVisualStyleBackColor = true;
            // 
            // A13
            // 
            this.A13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A13.Location = new System.Drawing.Point(4, 106);
            this.A13.Margin = new System.Windows.Forms.Padding(4);
            this.A13.Name = "A13";
            this.A13.Size = new System.Drawing.Size(80, 43);
            this.A13.TabIndex = 22;
            this.A13.Text = "A\r\n13";
            this.A13.UseVisualStyleBackColor = true;
            // 
            // A14
            // 
            this.A14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A14.Location = new System.Drawing.Point(92, 106);
            this.A14.Margin = new System.Windows.Forms.Padding(4);
            this.A14.Name = "A14";
            this.A14.Size = new System.Drawing.Size(80, 43);
            this.A14.TabIndex = 23;
            this.A14.Text = "A\r\n14";
            this.A14.UseVisualStyleBackColor = true;
            // 
            // A15
            // 
            this.A15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A15.Location = new System.Drawing.Point(180, 106);
            this.A15.Margin = new System.Windows.Forms.Padding(4);
            this.A15.Name = "A15";
            this.A15.Size = new System.Drawing.Size(80, 43);
            this.A15.TabIndex = 24;
            this.A15.Text = "A\r\n15";
            this.A15.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanelC
            // 
            this.flowLayoutPanelC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.flowLayoutPanelC.Controls.Add(this.C1);
            this.flowLayoutPanelC.Controls.Add(this.C2);
            this.flowLayoutPanelC.Controls.Add(this.C3);
            this.flowLayoutPanelC.Controls.Add(this.C4);
            this.flowLayoutPanelC.Controls.Add(this.C5);
            this.flowLayoutPanelC.Controls.Add(this.C6);
            this.flowLayoutPanelC.Controls.Add(this.C7);
            this.flowLayoutPanelC.Controls.Add(this.C8);
            this.flowLayoutPanelC.Controls.Add(this.C9);
            this.flowLayoutPanelC.Controls.Add(this.C10);
            this.flowLayoutPanelC.Controls.Add(this.C11);
            this.flowLayoutPanelC.Controls.Add(this.C12);
            this.flowLayoutPanelC.Controls.Add(this.C13);
            this.flowLayoutPanelC.Controls.Add(this.C14);
            this.flowLayoutPanelC.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanelC.Location = new System.Drawing.Point(4, 8);
            this.flowLayoutPanelC.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanelC.Name = "flowLayoutPanelC";
            this.flowLayoutPanelC.Size = new System.Drawing.Size(616, 107);
            this.flowLayoutPanelC.TabIndex = 1;
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(4, 4);
            this.C1.Margin = new System.Windows.Forms.Padding(4);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(80, 43);
            this.C1.TabIndex = 0;
            this.C1.Text = "C\r\n1";
            this.C1.UseVisualStyleBackColor = true;
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(92, 4);
            this.C2.Margin = new System.Windows.Forms.Padding(4);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(80, 43);
            this.C2.TabIndex = 1;
            this.C2.Text = "C\r\n2";
            this.C2.UseVisualStyleBackColor = true;
            // 
            // C3
            // 
            this.C3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(180, 4);
            this.C3.Margin = new System.Windows.Forms.Padding(4);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(80, 43);
            this.C3.TabIndex = 2;
            this.C3.Text = "C\r\n3";
            this.C3.UseVisualStyleBackColor = true;
            // 
            // C4
            // 
            this.C4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(268, 4);
            this.C4.Margin = new System.Windows.Forms.Padding(4);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(80, 43);
            this.C4.TabIndex = 3;
            this.C4.Text = "C\r\n4";
            this.C4.UseVisualStyleBackColor = true;
            // 
            // C5
            // 
            this.C5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(356, 4);
            this.C5.Margin = new System.Windows.Forms.Padding(4);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(80, 43);
            this.C5.TabIndex = 4;
            this.C5.Text = "C\r\n5";
            this.C5.UseVisualStyleBackColor = true;
            // 
            // C6
            // 
            this.C6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.Location = new System.Drawing.Point(444, 4);
            this.C6.Margin = new System.Windows.Forms.Padding(4);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(80, 43);
            this.C6.TabIndex = 5;
            this.C6.Text = "C\r\n6";
            this.C6.UseVisualStyleBackColor = true;
            // 
            // C7
            // 
            this.C7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.Location = new System.Drawing.Point(532, 4);
            this.C7.Margin = new System.Windows.Forms.Padding(4);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(80, 43);
            this.C7.TabIndex = 6;
            this.C7.Text = "C\r\n7";
            this.C7.UseVisualStyleBackColor = true;
            // 
            // C8
            // 
            this.C8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.Location = new System.Drawing.Point(4, 55);
            this.C8.Margin = new System.Windows.Forms.Padding(4);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(80, 43);
            this.C8.TabIndex = 7;
            this.C8.Text = "C\r\n8";
            this.C8.UseVisualStyleBackColor = true;
            // 
            // C9
            // 
            this.C9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C9.Location = new System.Drawing.Point(92, 55);
            this.C9.Margin = new System.Windows.Forms.Padding(4);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(80, 43);
            this.C9.TabIndex = 8;
            this.C9.Text = "C\r\n9";
            this.C9.UseVisualStyleBackColor = true;
            // 
            // C10
            // 
            this.C10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C10.Location = new System.Drawing.Point(180, 55);
            this.C10.Margin = new System.Windows.Forms.Padding(4);
            this.C10.Name = "C10";
            this.C10.Size = new System.Drawing.Size(80, 43);
            this.C10.TabIndex = 9;
            this.C10.Text = "C\r\n10";
            this.C10.UseVisualStyleBackColor = true;
            // 
            // C11
            // 
            this.C11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C11.Location = new System.Drawing.Point(268, 55);
            this.C11.Margin = new System.Windows.Forms.Padding(4);
            this.C11.Name = "C11";
            this.C11.Size = new System.Drawing.Size(80, 43);
            this.C11.TabIndex = 10;
            this.C11.Text = "C\r\n11";
            this.C11.UseVisualStyleBackColor = true;
            // 
            // C12
            // 
            this.C12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C12.Location = new System.Drawing.Point(356, 55);
            this.C12.Margin = new System.Windows.Forms.Padding(4);
            this.C12.Name = "C12";
            this.C12.Size = new System.Drawing.Size(80, 43);
            this.C12.TabIndex = 11;
            this.C12.Text = "C\r\n12";
            this.C12.UseVisualStyleBackColor = true;
            // 
            // C13
            // 
            this.C13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C13.Location = new System.Drawing.Point(444, 55);
            this.C13.Margin = new System.Windows.Forms.Padding(4);
            this.C13.Name = "C13";
            this.C13.Size = new System.Drawing.Size(80, 43);
            this.C13.TabIndex = 12;
            this.C13.Text = "C\r\n13";
            this.C13.UseVisualStyleBackColor = true;
            // 
            // C14
            // 
            this.C14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C14.Location = new System.Drawing.Point(532, 55);
            this.C14.Margin = new System.Windows.Forms.Padding(4);
            this.C14.Name = "C14";
            this.C14.Size = new System.Drawing.Size(80, 43);
            this.C14.TabIndex = 13;
            this.C14.Text = "C\r\n14";
            this.C14.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Color meaning:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel2.Location = new System.Drawing.Point(16, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(33, 27);
            this.panel2.TabIndex = 33;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Location = new System.Drawing.Point(16, 114);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(33, 27);
            this.panel3.TabIndex = 34;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel4.Location = new System.Drawing.Point(16, 147);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(33, 27);
            this.panel4.TabIndex = 34;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gray;
            this.panel5.Location = new System.Drawing.Point(16, 180);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(33, 27);
            this.panel5.TabIndex = 34;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Green;
            this.panel6.Location = new System.Drawing.Point(16, 213);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(33, 27);
            this.panel6.TabIndex = 34;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Red;
            this.panel7.Location = new System.Drawing.Point(16, 246);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(33, 27);
            this.panel7.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 17);
            this.label3.TabIndex = 35;
            this.label3.Text = "Band A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 17);
            this.label4.TabIndex = 36;
            this.label4.Text = "Band B";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 17);
            this.label5.TabIndex = 37;
            this.label5.Text = "Band C";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 17);
            this.label6.TabIndex = 38;
            this.label6.Text = "Available seat";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 213);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 17);
            this.label7.TabIndex = 39;
            this.label7.Text = "Your selected seat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(55, 246);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 17);
            this.label8.TabIndex = 40;
            this.label8.Text = "Reserved seat";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 299);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 17);
            this.label9.TabIndex = 41;
            this.label9.Text = "Booking subtotal:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 17);
            this.label10.TabIndex = 42;
            this.label10.Text = "label10";
            // 
            // SeatPlan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 561);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SeatPlan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SeatPlan";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SeatPlan_FormClosed);
            this.panel1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanelB.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanelC.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button A4;
        private System.Windows.Forms.Button A5;
        private System.Windows.Forms.Button A6;
        private System.Windows.Forms.Button A10;
        private System.Windows.Forms.Button A11;
        private System.Windows.Forms.Button A12;
        private System.Windows.Forms.Button A16;
        private System.Windows.Forms.Button A17;
        private System.Windows.Forms.Button A18;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B9;
        private System.Windows.Forms.Button B10;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Button C17;
        private System.Windows.Forms.Button C18;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelB;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Button C15;
        private System.Windows.Forms.Button C16;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A7;
        private System.Windows.Forms.Button A8;
        private System.Windows.Forms.Button A9;
        private System.Windows.Forms.Button A13;
        private System.Windows.Forms.Button A14;
        private System.Windows.Forms.Button A15;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelC;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button C4;
        private System.Windows.Forms.Button C5;
        private System.Windows.Forms.Button C6;
        private System.Windows.Forms.Button C7;
        private System.Windows.Forms.Button C8;
        private System.Windows.Forms.Button C9;
        private System.Windows.Forms.Button C10;
        private System.Windows.Forms.Button C11;
        private System.Windows.Forms.Button C12;
        private System.Windows.Forms.Button C13;
        private System.Windows.Forms.Button C14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Booking;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}