﻿namespace SystemsDevProject
{
    partial class SeatPlan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.A4 = new System.Windows.Forms.Button();
            this.A5 = new System.Windows.Forms.Button();
            this.A6 = new System.Windows.Forms.Button();
            this.A10 = new System.Windows.Forms.Button();
            this.A11 = new System.Windows.Forms.Button();
            this.A12 = new System.Windows.Forms.Button();
            this.A16 = new System.Windows.Forms.Button();
            this.A17 = new System.Windows.Forms.Button();
            this.A18 = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.B17 = new System.Windows.Forms.Button();
            this.B18 = new System.Windows.Forms.Button();
            this.B19 = new System.Windows.Forms.Button();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.C20 = new System.Windows.Forms.Button();
            this.C21 = new System.Windows.Forms.Button();
            this.flowLayoutPanelB = new System.Windows.Forms.FlowLayoutPanel();
            this.B1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.C15 = new System.Windows.Forms.Button();
            this.C16 = new System.Windows.Forms.Button();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.A1 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A7 = new System.Windows.Forms.Button();
            this.A8 = new System.Windows.Forms.Button();
            this.A9 = new System.Windows.Forms.Button();
            this.A13 = new System.Windows.Forms.Button();
            this.A14 = new System.Windows.Forms.Button();
            this.A15 = new System.Windows.Forms.Button();
            this.flowLayoutPanelC = new System.Windows.Forms.FlowLayoutPanel();
            this.C1 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C3 = new System.Windows.Forms.Button();
            this.C4 = new System.Windows.Forms.Button();
            this.C5 = new System.Windows.Forms.Button();
            this.C6 = new System.Windows.Forms.Button();
            this.C7 = new System.Windows.Forms.Button();
            this.C8 = new System.Windows.Forms.Button();
            this.C9 = new System.Windows.Forms.Button();
            this.C10 = new System.Windows.Forms.Button();
            this.C11 = new System.Windows.Forms.Button();
            this.C12 = new System.Windows.Forms.Button();
            this.C13 = new System.Windows.Forms.Button();
            this.C14 = new System.Windows.Forms.Button();
            this.Booking = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanelB.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanelC.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(254, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 23);
            this.label1.TabIndex = 30;
            this.label1.Text = "Seat Selection";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Booking);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.flowLayoutPanel2);
            this.panel1.Controls.Add(this.flowLayoutPanel5);
            this.panel1.Controls.Add(this.flowLayoutPanelB);
            this.panel1.Controls.Add(this.flowLayoutPanel3);
            this.panel1.Controls.Add(this.flowLayoutPanel4);
            this.panel1.Controls.Add(this.flowLayoutPanelC);
            this.panel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(12, 65);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 456);
            this.panel1.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSalmon;
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(154, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(361, 39);
            this.button1.TabIndex = 36;
            this.button1.Text = "Stage";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Silver;
            this.flowLayoutPanel1.Controls.Add(this.A4);
            this.flowLayoutPanel1.Controls.Add(this.A5);
            this.flowLayoutPanel1.Controls.Add(this.A6);
            this.flowLayoutPanel1.Controls.Add(this.A10);
            this.flowLayoutPanel1.Controls.Add(this.A11);
            this.flowLayoutPanel1.Controls.Add(this.A12);
            this.flowLayoutPanel1.Controls.Add(this.A16);
            this.flowLayoutPanel1.Controls.Add(this.A17);
            this.flowLayoutPanel1.Controls.Add(this.A18);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(353, 202);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(162, 130);
            this.flowLayoutPanel1.TabIndex = 31;
            // 
            // A4
            // 
            this.A4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(3, 3);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(45, 35);
            this.A4.TabIndex = 16;
            this.A4.Text = "A\r\n4";
            this.A4.UseVisualStyleBackColor = true;
            // 
            // A5
            // 
            this.A5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(54, 3);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(45, 35);
            this.A5.TabIndex = 17;
            this.A5.Text = "A\r\n5";
            this.A5.UseVisualStyleBackColor = true;
            // 
            // A6
            // 
            this.A6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.Location = new System.Drawing.Point(105, 3);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(45, 35);
            this.A6.TabIndex = 18;
            this.A6.Text = "A\r\n6";
            this.A6.UseVisualStyleBackColor = true;
            // 
            // A10
            // 
            this.A10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A10.Location = new System.Drawing.Point(3, 44);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(45, 35);
            this.A10.TabIndex = 19;
            this.A10.Text = "A\r\n10";
            this.A10.UseVisualStyleBackColor = true;
            // 
            // A11
            // 
            this.A11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A11.Location = new System.Drawing.Point(54, 44);
            this.A11.Name = "A11";
            this.A11.Size = new System.Drawing.Size(45, 35);
            this.A11.TabIndex = 20;
            this.A11.Text = "A\r11";
            this.A11.UseVisualStyleBackColor = true;
            // 
            // A12
            // 
            this.A12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A12.Location = new System.Drawing.Point(105, 44);
            this.A12.Name = "A12";
            this.A12.Size = new System.Drawing.Size(45, 35);
            this.A12.TabIndex = 21;
            this.A12.Text = "A\r\n12";
            this.A12.UseVisualStyleBackColor = true;
            // 
            // A16
            // 
            this.A16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A16.Location = new System.Drawing.Point(3, 85);
            this.A16.Name = "A16";
            this.A16.Size = new System.Drawing.Size(45, 35);
            this.A16.TabIndex = 22;
            this.A16.Text = "A\r16";
            this.A16.UseVisualStyleBackColor = true;
            // 
            // A17
            // 
            this.A17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A17.Location = new System.Drawing.Point(54, 85);
            this.A17.Name = "A17";
            this.A17.Size = new System.Drawing.Size(45, 35);
            this.A17.TabIndex = 23;
            this.A17.Text = "A\r\n17";
            this.A17.UseVisualStyleBackColor = true;
            // 
            // A18
            // 
            this.A18.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A18.Location = new System.Drawing.Point(105, 85);
            this.A18.Name = "A18";
            this.A18.Size = new System.Drawing.Size(45, 35);
            this.A18.TabIndex = 24;
            this.A18.Text = "A\r\n18";
            this.A18.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.Gray;
            this.flowLayoutPanel2.Controls.Add(this.B17);
            this.flowLayoutPanel2.Controls.Add(this.B18);
            this.flowLayoutPanel2.Controls.Add(this.B19);
            this.flowLayoutPanel2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel2.Location = new System.Drawing.Point(256, 101);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(153, 45);
            this.flowLayoutPanel2.TabIndex = 33;
            // 
            // B17
            // 
            this.B17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B17.Location = new System.Drawing.Point(3, 3);
            this.B17.Name = "B17";
            this.B17.Size = new System.Drawing.Size(45, 35);
            this.B17.TabIndex = 27;
            this.B17.Text = "B\r\n17";
            this.B17.UseVisualStyleBackColor = true;
            // 
            // B18
            // 
            this.B18.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B18.Location = new System.Drawing.Point(54, 3);
            this.B18.Name = "B18";
            this.B18.Size = new System.Drawing.Size(45, 35);
            this.B18.TabIndex = 28;
            this.B18.Text = "B\r\n18";
            this.B18.UseVisualStyleBackColor = true;
            // 
            // B19
            // 
            this.B19.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B19.Location = new System.Drawing.Point(105, 3);
            this.B19.Name = "B19";
            this.B19.Size = new System.Drawing.Size(45, 35);
            this.B19.TabIndex = 29;
            this.B19.Text = "B\r\n19";
            this.B19.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.flowLayoutPanel5.Controls.Add(this.C20);
            this.flowLayoutPanel5.Controls.Add(this.C21);
            this.flowLayoutPanel5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel5.Location = new System.Drawing.Point(412, 101);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(103, 45);
            this.flowLayoutPanel5.TabIndex = 35;
            // 
            // C20
            // 
            this.C20.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C20.Location = new System.Drawing.Point(3, 3);
            this.C20.Name = "C20";
            this.C20.Size = new System.Drawing.Size(45, 35);
            this.C20.TabIndex = 25;
            this.C20.Text = "C\r\n20";
            this.C20.UseVisualStyleBackColor = true;
            // 
            // C21
            // 
            this.C21.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C21.Location = new System.Drawing.Point(54, 3);
            this.C21.Name = "C21";
            this.C21.Size = new System.Drawing.Size(45, 35);
            this.C21.TabIndex = 26;
            this.C21.Text = "C\r\n21";
            this.C21.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanelB
            // 
            this.flowLayoutPanelB.BackColor = System.Drawing.Color.Gray;
            this.flowLayoutPanelB.Controls.Add(this.B1);
            this.flowLayoutPanelB.Controls.Add(this.B2);
            this.flowLayoutPanelB.Controls.Add(this.B3);
            this.flowLayoutPanelB.Controls.Add(this.B4);
            this.flowLayoutPanelB.Controls.Add(this.B5);
            this.flowLayoutPanelB.Controls.Add(this.B6);
            this.flowLayoutPanelB.Controls.Add(this.B7);
            this.flowLayoutPanelB.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanelB.Location = new System.Drawing.Point(151, 152);
            this.flowLayoutPanelB.Name = "flowLayoutPanelB";
            this.flowLayoutPanelB.Size = new System.Drawing.Size(364, 44);
            this.flowLayoutPanelB.TabIndex = 30;
            // 
            // B1
            // 
            this.B1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(3, 3);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(45, 35);
            this.B1.TabIndex = 15;
            this.B1.Text = "B\r\n1";
            this.B1.UseVisualStyleBackColor = true;
            // 
            // B2
            // 
            this.B2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(54, 3);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(45, 35);
            this.B2.TabIndex = 16;
            this.B2.Text = "B\r\n2";
            this.B2.UseVisualStyleBackColor = true;
            // 
            // B3
            // 
            this.B3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(105, 3);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(45, 35);
            this.B3.TabIndex = 17;
            this.B3.Text = "B\r\n3";
            this.B3.UseVisualStyleBackColor = true;
            // 
            // B4
            // 
            this.B4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(156, 3);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(45, 35);
            this.B4.TabIndex = 18;
            this.B4.Text = "B\r\n4";
            this.B4.UseVisualStyleBackColor = true;
            // 
            // B5
            // 
            this.B5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(207, 3);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(45, 35);
            this.B5.TabIndex = 19;
            this.B5.Text = "B\r\n5";
            this.B5.UseVisualStyleBackColor = true;
            // 
            // B6
            // 
            this.B6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(258, 3);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(45, 35);
            this.B6.TabIndex = 20;
            this.B6.Text = "B\r\n6";
            this.B6.UseVisualStyleBackColor = true;
            // 
            // B7
            // 
            this.B7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(309, 3);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(45, 35);
            this.B7.TabIndex = 21;
            this.B7.Text = "B\r\n7";
            this.B7.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.flowLayoutPanel3.Controls.Add(this.C15);
            this.flowLayoutPanel3.Controls.Add(this.C16);
            this.flowLayoutPanel3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel3.Location = new System.Drawing.Point(151, 101);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(102, 45);
            this.flowLayoutPanel3.TabIndex = 34;
            // 
            // C15
            // 
            this.C15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C15.Location = new System.Drawing.Point(3, 3);
            this.C15.Name = "C15";
            this.C15.Size = new System.Drawing.Size(45, 35);
            this.C15.TabIndex = 25;
            this.C15.Text = "C\r\n15";
            this.C15.UseVisualStyleBackColor = true;
            // 
            // C16
            // 
            this.C16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C16.Location = new System.Drawing.Point(54, 3);
            this.C16.Name = "C16";
            this.C16.Size = new System.Drawing.Size(45, 35);
            this.C16.TabIndex = 26;
            this.C16.Text = "C\r\n16";
            this.C16.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.Color.Silver;
            this.flowLayoutPanel4.Controls.Add(this.A1);
            this.flowLayoutPanel4.Controls.Add(this.A2);
            this.flowLayoutPanel4.Controls.Add(this.A3);
            this.flowLayoutPanel4.Controls.Add(this.A7);
            this.flowLayoutPanel4.Controls.Add(this.A8);
            this.flowLayoutPanel4.Controls.Add(this.A9);
            this.flowLayoutPanel4.Controls.Add(this.A13);
            this.flowLayoutPanel4.Controls.Add(this.A14);
            this.flowLayoutPanel4.Controls.Add(this.A15);
            this.flowLayoutPanel4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel4.Location = new System.Drawing.Point(151, 202);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(161, 130);
            this.flowLayoutPanel4.TabIndex = 32;
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(3, 3);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(45, 35);
            this.A1.TabIndex = 16;
            this.A1.Text = "A\r\n1";
            this.A1.UseVisualStyleBackColor = true;
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(54, 3);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(45, 35);
            this.A2.TabIndex = 17;
            this.A2.Text = "A\r\n2";
            this.A2.UseVisualStyleBackColor = true;
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(105, 3);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(45, 35);
            this.A3.TabIndex = 18;
            this.A3.Text = "A\r\n3";
            this.A3.UseVisualStyleBackColor = true;
            // 
            // A7
            // 
            this.A7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A7.Location = new System.Drawing.Point(3, 44);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(45, 35);
            this.A7.TabIndex = 19;
            this.A7.Text = "A\r\n7";
            this.A7.UseVisualStyleBackColor = true;
            // 
            // A8
            // 
            this.A8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A8.Location = new System.Drawing.Point(54, 44);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(45, 35);
            this.A8.TabIndex = 20;
            this.A8.Text = "A\r\n8";
            this.A8.UseVisualStyleBackColor = true;
            // 
            // A9
            // 
            this.A9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A9.Location = new System.Drawing.Point(105, 44);
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(45, 35);
            this.A9.TabIndex = 21;
            this.A9.Text = "A\r\n9";
            this.A9.UseVisualStyleBackColor = true;
            // 
            // A13
            // 
            this.A13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A13.Location = new System.Drawing.Point(3, 85);
            this.A13.Name = "A13";
            this.A13.Size = new System.Drawing.Size(45, 35);
            this.A13.TabIndex = 22;
            this.A13.Text = "A\r\n13";
            this.A13.UseVisualStyleBackColor = true;
            // 
            // A14
            // 
            this.A14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A14.Location = new System.Drawing.Point(54, 85);
            this.A14.Name = "A14";
            this.A14.Size = new System.Drawing.Size(45, 35);
            this.A14.TabIndex = 23;
            this.A14.Text = "A\r\n14";
            this.A14.UseVisualStyleBackColor = true;
            // 
            // A15
            // 
            this.A15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A15.Location = new System.Drawing.Point(105, 85);
            this.A15.Name = "A15";
            this.A15.Size = new System.Drawing.Size(45, 35);
            this.A15.TabIndex = 24;
            this.A15.Text = "A\r\n15";
            this.A15.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanelC
            // 
            this.flowLayoutPanelC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.flowLayoutPanelC.Controls.Add(this.C1);
            this.flowLayoutPanelC.Controls.Add(this.C2);
            this.flowLayoutPanelC.Controls.Add(this.C3);
            this.flowLayoutPanelC.Controls.Add(this.C4);
            this.flowLayoutPanelC.Controls.Add(this.C5);
            this.flowLayoutPanelC.Controls.Add(this.C6);
            this.flowLayoutPanelC.Controls.Add(this.C7);
            this.flowLayoutPanelC.Controls.Add(this.C8);
            this.flowLayoutPanelC.Controls.Add(this.C9);
            this.flowLayoutPanelC.Controls.Add(this.C10);
            this.flowLayoutPanelC.Controls.Add(this.C11);
            this.flowLayoutPanelC.Controls.Add(this.C12);
            this.flowLayoutPanelC.Controls.Add(this.C13);
            this.flowLayoutPanelC.Controls.Add(this.C14);
            this.flowLayoutPanelC.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanelC.Location = new System.Drawing.Point(151, 6);
            this.flowLayoutPanelC.Name = "flowLayoutPanelC";
            this.flowLayoutPanelC.Size = new System.Drawing.Size(364, 88);
            this.flowLayoutPanelC.TabIndex = 1;
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(3, 3);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(45, 35);
            this.C1.TabIndex = 0;
            this.C1.Text = "C\r\n1";
            this.C1.UseVisualStyleBackColor = true;
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(54, 3);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(45, 35);
            this.C2.TabIndex = 1;
            this.C2.Text = "C\r\n2";
            this.C2.UseVisualStyleBackColor = true;
            // 
            // C3
            // 
            this.C3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(105, 3);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(45, 35);
            this.C3.TabIndex = 2;
            this.C3.Text = "C\r\n3";
            this.C3.UseVisualStyleBackColor = true;
            // 
            // C4
            // 
            this.C4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(156, 3);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(45, 35);
            this.C4.TabIndex = 3;
            this.C4.Text = "C\r\n4";
            this.C4.UseVisualStyleBackColor = true;
            // 
            // C5
            // 
            this.C5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(207, 3);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(45, 35);
            this.C5.TabIndex = 4;
            this.C5.Text = "C\r\n5";
            this.C5.UseVisualStyleBackColor = true;
            // 
            // C6
            // 
            this.C6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.Location = new System.Drawing.Point(258, 3);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(45, 35);
            this.C6.TabIndex = 5;
            this.C6.Text = "C\r\n6";
            this.C6.UseVisualStyleBackColor = true;
            // 
            // C7
            // 
            this.C7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.Location = new System.Drawing.Point(309, 3);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(45, 35);
            this.C7.TabIndex = 6;
            this.C7.Text = "C\r\n7";
            this.C7.UseVisualStyleBackColor = true;
            // 
            // C8
            // 
            this.C8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.Location = new System.Drawing.Point(3, 44);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(45, 35);
            this.C8.TabIndex = 7;
            this.C8.Text = "C\r\n8";
            this.C8.UseVisualStyleBackColor = true;
            // 
            // C9
            // 
            this.C9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C9.Location = new System.Drawing.Point(54, 44);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(45, 35);
            this.C9.TabIndex = 8;
            this.C9.Text = "C\r\n9";
            this.C9.UseVisualStyleBackColor = true;
            // 
            // C10
            // 
            this.C10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C10.Location = new System.Drawing.Point(105, 44);
            this.C10.Name = "C10";
            this.C10.Size = new System.Drawing.Size(45, 35);
            this.C10.TabIndex = 9;
            this.C10.Text = "C\r\n10";
            this.C10.UseVisualStyleBackColor = true;
            // 
            // C11
            // 
            this.C11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C11.Location = new System.Drawing.Point(156, 44);
            this.C11.Name = "C11";
            this.C11.Size = new System.Drawing.Size(45, 35);
            this.C11.TabIndex = 10;
            this.C11.Text = "C\r\n11";
            this.C11.UseVisualStyleBackColor = true;
            // 
            // C12
            // 
            this.C12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C12.Location = new System.Drawing.Point(207, 44);
            this.C12.Name = "C12";
            this.C12.Size = new System.Drawing.Size(45, 35);
            this.C12.TabIndex = 11;
            this.C12.Text = "C\r\n12";
            this.C12.UseVisualStyleBackColor = true;
            // 
            // C13
            // 
            this.C13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C13.Location = new System.Drawing.Point(258, 44);
            this.C13.Name = "C13";
            this.C13.Size = new System.Drawing.Size(45, 35);
            this.C13.TabIndex = 12;
            this.C13.Text = "C\r\n13";
            this.C13.UseVisualStyleBackColor = true;
            // 
            // C14
            // 
            this.C14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C14.Location = new System.Drawing.Point(309, 44);
            this.C14.Name = "C14";
            this.C14.Size = new System.Drawing.Size(45, 35);
            this.C14.TabIndex = 13;
            this.C14.Text = "C\r\n14";
            this.C14.UseVisualStyleBackColor = true;
            // 
            // Booking
            // 
            this.Booking.Location = new System.Drawing.Point(256, 423);
            this.Booking.Name = "Booking";
            this.Booking.Size = new System.Drawing.Size(134, 30);
            this.Booking.TabIndex = 37;
            this.Booking.Text = "Confirm Booking";
            this.Booking.UseVisualStyleBackColor = true;
            this.Booking.Click += new System.EventHandler(this.Booking_Click);
            // 
            // SeatPlan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 533);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "SeatPlan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SeatPlan";
            this.Load += new System.EventHandler(this.SeatPlan_Load);
            this.panel1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanelB.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanelC.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button A4;
        private System.Windows.Forms.Button A5;
        private System.Windows.Forms.Button A6;
        private System.Windows.Forms.Button A10;
        private System.Windows.Forms.Button A11;
        private System.Windows.Forms.Button A12;
        private System.Windows.Forms.Button A16;
        private System.Windows.Forms.Button A17;
        private System.Windows.Forms.Button A18;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button B17;
        private System.Windows.Forms.Button B18;
        private System.Windows.Forms.Button B19;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Button C20;
        private System.Windows.Forms.Button C21;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelB;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Button C15;
        private System.Windows.Forms.Button C16;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A7;
        private System.Windows.Forms.Button A8;
        private System.Windows.Forms.Button A9;
        private System.Windows.Forms.Button A13;
        private System.Windows.Forms.Button A14;
        private System.Windows.Forms.Button A15;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelC;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button C4;
        private System.Windows.Forms.Button C5;
        private System.Windows.Forms.Button C6;
        private System.Windows.Forms.Button C7;
        private System.Windows.Forms.Button C8;
        private System.Windows.Forms.Button C9;
        private System.Windows.Forms.Button C10;
        private System.Windows.Forms.Button C11;
        private System.Windows.Forms.Button C12;
        private System.Windows.Forms.Button C13;
        private System.Windows.Forms.Button C14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Booking;
    }
}