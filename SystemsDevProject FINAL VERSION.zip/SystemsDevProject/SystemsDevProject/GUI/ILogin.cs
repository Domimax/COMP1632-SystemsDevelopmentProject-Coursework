﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject.GUI
{
    //Interface for logging in purposes as well as for enabling forms
    public interface ILogin
    {
        void UpdateLoggedInUserName();
        void UpdateEnabledProperty(bool enabled);
    }
}
