﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;
using SystemsDevProject.Model;

namespace SystemsDevProject
{
    // A Database class which uses a Singleton pattern to only allow a single instance of itself and is used for interaction
    //with a database.
    internal sealed class DBSingleton
    {
        //A lock object to make the accessing of a single instance thread safe.
        private static readonly object padlock = new object();
        //A Singleton instance of the class.
        private static DBSingleton instance = null;

        //Property used for the retrieval of the Singleton instance.
        public static DBSingleton GetDBSingletonInstance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new DBSingleton();
                    }
                    return instance;
                }
            }
        }

        // Constructor. Used only once.
        private DBSingleton()
        {

        }
        //Method to add card details into database
        public void InsertCardDetails(CardDetails cardDetails, int bookingID)
        {
            //insert query to add card details in database
            OleDbConnection connection = GetOleDbConnection();
            string query = "INSERT INTO CardDetails (NameOnCard, CardNumber, CardType, ExpirationDate, CVV, BookingID) VALUES ('" +
                cardDetails.NameOnCard + "' , '" + cardDetails.CardNumber + "' , '" + cardDetails.CardType + "' , '"
                + cardDetails.ExpirationDate + "' , '" + cardDetails.CVV + "' , '" + bookingID + "');";
            OleDbCommand command = new OleDbCommand(query, connection);
            try //to open connection to database
            {
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally // close connection
            {
                connection.Close();
            }
        }
        //Method to add ticket details into database
        public void InsertTicket(Ticket ticket, int bookingID)
        {
            //insert query to add card details in database
            OleDbConnection connection = GetOleDbConnection();
            string query = "INSERT INTO Ticket (TicketPrice, TicketType, TicketDescription, BookingID, SeatID) VALUES ('" +
                ticket.TicketPrice + "' , '" + ticket.TicketType + "' , '" + ticket.TicketDescription + "' , '"
                + bookingID + "' , '" + ticket.TicketSeat.SeatID + "');";
            string occupiedQuery = "UPDATE Seat SET Occupied = 1 " + "WHERE ID = " + ticket.TicketSeat.SeatID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            OleDbCommand occupiedCommand = new OleDbCommand(occupiedQuery, connection);
            try //to open connection to database
            {
                connection.Open();
                command.ExecuteNonQuery();
                occupiedCommand.ExecuteNonQuery();
            }
            catch (Exception ex) //handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally
            {
                connection.Close();//close connection
            }
        }
        //Method to add booking details into the database
        public int InsertBooking(Booking booking, int userID)
        {
            int bookingID = 0;
            //insert query to add card details in database
            OleDbConnection connection = GetOleDbConnection();
            string query = "INSERT INTO [Booking] (BookingDate, TotalCost, CollectionType, UserID) VALUES ('" + booking.BookingDate +
                "' , '" + booking.TotalCost + "' , '" + booking.CollectionType + "' , '" + userID + "');";
            OleDbCommand command = new OleDbCommand(query, connection);
            string bookingIDQuery = "SELECT MAX(ID) FROM [Booking];";
            OleDbCommand bookingIDCommand = new OleDbCommand(bookingIDQuery, connection);
            try// to open connection to database
            {
                connection.Open();
                command.ExecuteNonQuery();
                bookingID = (int)bookingIDCommand.ExecuteScalar();
            }
            catch (Exception ex) //handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally // close connection to database
            {
                connection.Close();
            }
            return bookingID;
        }

        // Method returns a database connection.
        private OleDbConnection GetOleDbConnection()
        {
            String connection = @"Provider=Microsoft.JET.OLEDB.4.0; 
				 Data Source =" + Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"DB\SystemsDevProjectDB.mdb");
            OleDbConnection myConnection = new OleDbConnection(connection);
            return myConnection;
        }
        //Method returns a list of plays from the database
        public List<Play> GetPlays()
        {
            List<Play> plays = new List<Play>();
            OleDbConnection connection = GetOleDbConnection();
            string query = "SELECT * FROM Play;";
            OleDbCommand playCommand = new OleDbCommand(query, connection);
            try //to open a connection to the database
            {
                connection.Open();
                OleDbDataReader playReader = playCommand.ExecuteReader();
                while (playReader.Read()) // keep reading until there is no content left
                {
                    int id = (int)playReader["ID"];
                    string playName = (string)playReader["PlayName"];
                    int playDuration = (int)playReader["PlayDuration"];
                    string playCast = (string)playReader["PlayCast"];
                    string pictureString = (string)playReader["PictureString"];
                    Play newPlay = new Play();
                    //store id, name etc details into variables
                    newPlay.PlayID = id;
                    newPlay.PlayName = playName;
                    newPlay.PlayDuration = playDuration;
                    newPlay.PlayCast = playCast;
                    newPlay.PictureString = pictureString;
                    newPlay.PlayPerformances = GetPerformances(id, connection);
                    plays.Add(newPlay);
                }
            }
            catch (Exception ex) //handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally //close the connection to the dtabase
            {
                connection.Close();
            }
            return plays;
        }
        //Method that returns a list of performance instances
        private List<Performance> GetPerformances(int playId, OleDbConnection connection)
        {
            List<Performance> performances = new List<Performance>();
            string query = "SELECT * FROM Performance WHERE PlayID = " + playId + ";";
            OleDbCommand performanceCommand = new OleDbCommand(query, connection);
            try 
            {
                OleDbDataReader performanceReader = performanceCommand.ExecuteReader();
                while (performanceReader.Read())
                {
                    //initialise variables with data from database
                    int id = (int)performanceReader["ID"];
                    DateTime performanceDate = (DateTime)performanceReader["PerformanceDate"];
                    string performanceStatus = (string)performanceReader["PerformanceStatus"];
                    Performance newPerformance = new Performance();
                    newPerformance.PerformanceID = id;
                    newPerformance.PerformanceDate = performanceDate;
                    newPerformance.PerformanceStatus = performanceStatus;
                    newPerformance.PerformanceBands = GetBands(id, connection);
                    performances.Add(newPerformance);
                }
            }
            catch (Exception ex)//handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return performances;
        }
        //Method that returns list of type band
        private List<Band> GetBands(int performanceID, OleDbConnection connection)
        {
            List<Band> bands = new List<Band>();
            string query = "SELECT * FROM [Band] WHERE PerformanceID = " + performanceID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            try
            {
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = (int)reader["ID"];
                    string bandNumber = (string)reader["BandNumber"];
                    double bandPrice = (int)reader["BandPrice"];
                    Band newBand = new Band();
                    newBand.BandID = id;
                    newBand.BandNumber = bandNumber;
                    newBand.BandPrice = bandPrice;
                    newBand.BandSeats = GetSeats(id, connection);
                    bands.Add(newBand);
                }
            }
            catch (Exception ex)//handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return bands;
        }
        //Method that gets the seats from the data within the database
        private List<Seat> GetSeats(int bandID, OleDbConnection connection)
        {
            List<Seat> seats = new List<Seat>();
            string query = "SELECT * FROM Seat WHERE BandID = " + bandID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            try
            {
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = (int)reader["ID"];
                    int seatNumber = (int)reader["SeatNumber"];
                    bool occupied = (bool)reader["Occupied"];
                    Seat newSeat = new Seat();
                    newSeat.SeatID = id;
                    newSeat.SeatNumber = seatNumber;
                    newSeat.Occupied = occupied;
                    seats.Add(newSeat);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return seats;
        }
        //Method that gets user from the database
        public User GetUser(string username, string password)
        {
            User user = null;
            OleDbConnection connection = GetOleDbConnection();
            string userQuery = "SELECT * FROM [User] WHERE Username = '" + username + "' AND Password = '" + password + "';";
            OleDbCommand userCommand = new OleDbCommand(userQuery, connection);
            try // to open a connection with the database
            {
                connection.Open();
                OleDbDataReader userReader = userCommand.ExecuteReader();
                while (userReader.Read())
                {
                    if ((string)userReader["UserType"] == "Employee")
                    {
                        user = GetEmployee(connection, (int)userReader["ID"]);//initialise variables by reading data from the database
                    }
                    else if ((string)userReader["UserType"] == "Agency")
                    {
                        user = GetAgency(connection, (int)userReader["ID"]);
                    }
                    else
                    {
                        user = GetCustomer(connection, (int)userReader["ID"]);
                    }
                    user.InitialiseUser((int)userReader["ID"], (string)userReader["FirstName"], (string)userReader["LastName"],
                        (string)userReader["Address"], (string)userReader["MobileNumber"], (string)userReader["EmailAddress"],
                        (string)userReader["Username"]);
                }
            }
            catch (Exception ex)// handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally //close connection to the database
            {
                connection.Close();
            }
            return user;
        }
        //Method that gets the required employee from the database
        private Employee GetEmployee(OleDbConnection connection, int userID)
        {
            string query = "SELECT * FROM Employee WHERE UserID = " + userID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            Employee employee = null;
            try // to read from the database
            {
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    employee = (Employee)UserFactory.CreateUser("Employee");
                    employee.EmployeeID = (int)reader["ID"];
                    employee.Role = (string)reader["Role"];
                    employee.Salary = (int)reader["Salary"];
                }
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return employee;
        }
        //Method that returns an agency from the database
        private Agency GetAgency(OleDbConnection connection, int userID)
        {
            string query = "SELECT * FROM Agency WHERE UserID = " + userID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            Agency agency = null;
            try // to read from the database
            {
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    agency = (Agency)UserFactory.CreateUser("Agency");
                    agency.AgencyID = (int)reader["ID"];
                    agency.AgencyName = (string)reader["AgencyName"];
                }
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return agency;
        }
        //Method that returns a customer from the database
        private Customer GetCustomer(OleDbConnection connection, int userID)
        {
            string query = "SELECT * FROM Customer WHERE UserID = " + userID + ";";
            OleDbCommand command = new OleDbCommand(query, connection);
            Customer customer = null;
            try // to read from the database
            {
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    customer = (Customer)UserFactory.CreateUser("Customer");
                    customer.CustomerID = (int)reader["ID"];
                    customer.DateOfBirth = (DateTime)reader["DateOfBirth"];
                }
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            return customer;
        }
        //Method that will register a new user as an employee
        public void RegisterEmployee(Employee employee, string password)
        {
            OleDbConnection connection = GetOleDbConnection();
            int userID = RegisterUser(connection, employee, password, "Agency");
            //A query used to insert a new tuple into the table.
            string employeeQuery = "INSERT INTO Employee (Role, Salary, UserID)" +
                " VALUES ('" + employee.Role + "', '" + employee.Salary + "', '" + userID + "');";
            OleDbCommand employeeCommand = new OleDbCommand(employeeQuery, connection);
            try // to open a connection to the database
            {
                connection.Open();
                employeeCommand.ExecuteNonQuery();
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally // close connetion
            {
                connection.Close();
            }
        }
        //Method that will register a new user as an agency
        public void RegisterAgency(Agency agency, string password)
        {
            OleDbConnection connection = GetOleDbConnection();
            int userID = RegisterUser(connection, agency, password, "Agency");
            //A query used to insert a new tuple into the table.
            string agencyQuery = "INSERT INTO Agency (AgencyName, UserID)" +
                " VALUES ('" + agency.AgencyName + "', '" + userID + "');";
            OleDbCommand agencyCommand = new OleDbCommand(agencyQuery, connection);
            try // to open a connection with the databse
            {
                connection.Open();
                agencyCommand.ExecuteNonQuery();
            }
            catch (Exception ex) // handle xceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally // close connection
            {
                connection.Close();
            }
        }
        //Method that will register a new user as a customer
        public void RegisterCustomer(Customer customer, string password)
        {
            OleDbConnection connection = GetOleDbConnection();
            int userID = RegisterUser(connection, customer, password, "Customer");//pass username and password as paramters
            string customerQuery = "INSERT INTO Customer (DateOfBirth, UserID)" +
                " VALUES ('" + customer.DateOfBirth + "', '" + userID + "');";
            OleDbCommand customerCommand = new OleDbCommand(customerQuery, connection);
            try // try to open a connection with a database
            {
                connection.Open();
                customerCommand.ExecuteNonQuery();
            }
            catch (Exception ex) // handle exceptions
            {
                System.Diagnostics.Debug.WriteLine("Exception: " + ex);
            }
            finally // close connection
            {
                connection.Close();
            }
        }
        //Method that will store the username and password of a user in the database
        private int RegisterUser(OleDbConnection connection, User user, string password, string type)
        {
            int userID = -1;
            string userQuery = "INSERT INTO [User] (FirstName, LastName, Address, MobileNumber, EmailAddress, Username, [Password], UserType) " +
                 "VALUES ('" + user.FirstName + "' , '" + user.LastName + "' , '" + user.Address + "' , '" + user.MobileNumber +
                 "' , '" + user.EmailAddress + "' , '" + user.Username + "' , '" + password + "' , '" + type + "');";
            OleDbCommand userCommand = new OleDbCommand(userQuery, connection);
            string userIDQuery = "SELECT MAX(ID) FROM [User];";
            OleDbCommand userIDCommand = new OleDbCommand(userIDQuery, connection);
            try // to open a connection to the database
            {
                connection.Open();
                userCommand.ExecuteNonQuery();
                userID = (int)userIDCommand.ExecuteScalar();
            }
            catch (Exception ex) // handle exceptions
            {
                Console.WriteLine("Exception: " + ex);
            }
            finally // close connection
            {
                connection.Close();
            }
            return userID;
        }
        //Method to save the review into the database
        public void InsertReview(int playID, DateTime date, string review, int rating, int userID)
        {
            OleDbConnection connection = GetOleDbConnection();
            string query = "INSERT INTO Review ( ReviewDate, ReviewText, Rating, PlayID, UserID) VALUES ( '" + date + "' , '" + review + "' , '" + rating + "' , '" + playID + "' , '" + userID + "')";
            OleDbCommand playCommand = new OleDbCommand(query, connection);
            try // to open a connection to the database
            {
                connection.Open();
                playCommand.ExecuteNonQuery();
            }
            catch (Exception ex) // handle exceptions
            {
                MessageBox.Show("Sorry. Unable to save your review right now. Please try again later: " + ex);
            }
            finally // close connection
            {
                connection.Close();
            }
        }
        //Method that will return the reviews from the database
        public List<String> readReview(int performanceID, List<String> r, List<int> i)
        {
            //Creating a connection
            OleDbConnection connection = GetOleDbConnection();
            string query = "SELECT * FROM [Review] WHERE PlayID =" + performanceID;
            OleDbCommand cmd = new OleDbCommand(query, connection);
            OleDbDataReader reader;
            //Clears the list on each instance to ensure reviews for other plays are not being stored
            r.Clear();
            i.Clear();
            try // to open connection to database
            {
                connection.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    r.Add(reader["ReviewText"].ToString());
                    i.Add((int)reader["Rating"]);
                }
            }
            catch (Exception ex) // handle exceptions
            {
                MessageBox.Show(ex.ToString());
            }
            finally // close connection
            {
                connection.Close();
            }
            return r;
        }
        //Method that will attempt to store the receipt
        public Receipt printReceipt(DateTime date, string seatNumber, double a, string performance)
        {
            Receipt r = new Receipt(date, seatNumber, a, performance);
            r.printReceipt();
            return r;
        }
    }
}
