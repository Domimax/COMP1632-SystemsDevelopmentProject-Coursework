﻿using SystemsDevProject.Model;

namespace SystemsDevProject
{
    public class UserFactory
    {
        //Factory pattern class to return different subtypes of the abstract class 'User'
        public static User CreateUser(string userType)
        {
            if (userType == "Employee")
            {
                return new Employee();
            }
            else if (userType == "Agency")
            {
                return new Agency();
            }
            else if (userType == "Customer")
            {
                return new Customer();
            }
            else
            {
                return null;
            }
        }
    }
}
