﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject.Model
{
    public class Customer : User
    {
        //enable getter and setters
        public int CustomerID { get; set; }
        public DateTime DateOfBirth { get; set; }

        //Constructor 1
        public Customer(int customerID, DateTime dateOfBirth)
        {
            CustomerID = customerID;
            DateOfBirth = dateOfBirth;
        }
        //Constructor 2
        public Customer(DateTime dateOfBirth)
        {
            DateOfBirth = dateOfBirth;
        }
        //Constructor 3
        public Customer()
        {

        }
    }
}
