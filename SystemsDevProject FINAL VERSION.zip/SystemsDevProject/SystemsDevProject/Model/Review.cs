﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject
{
    public class Review
    {
        //enable getter and setter
        public int ReviewID { get; set; }
        public string ReviewText { get; set; }
        public DateTime ReviewDate { get; set; }
        public int Rating { get; set; }

        //Constructor 1
        public Review()
        {

        }
        //Constructor 2
        public Review(string reviewText, DateTime reviewDate)
        {
            ReviewText = reviewText;
            ReviewDate = reviewDate;
        }
    }
}
