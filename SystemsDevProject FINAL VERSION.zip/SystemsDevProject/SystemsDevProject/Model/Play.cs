﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject
{
    public class Play
    {
        //enable getter and setter
        public int PlayID { get; set; }
        public string PlayName { get; set; }
        public int PlayDuration { get; set; }
        public string PlayCast { get; set; }
        public string PictureString { get; set; }

        public List<Review> PlayReviews { get; set; }
        public List<Performance> PlayPerformances { get; set; }

        //Constructor 1
        public Play()
        {

        }
        //Constructor 2
        public Play(string playName, int playDuration)
        {
            PlayName = playName;
            PlayDuration = playDuration;
            PlayReviews = new List<Review>();
            PlayPerformances = new List<Performance>();
        }
    }
}
