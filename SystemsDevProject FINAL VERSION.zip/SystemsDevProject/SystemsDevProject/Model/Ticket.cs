﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject
{
    public class Ticket
    {
        //enable getter and setter
        public int TicketID { get; set; }
        public double TicketPrice { get; set; }
        public string TicketDescription { get; set; }
        public string TicketType { get; set; }
        public Seat TicketSeat { get; set; }

        //Constructor 1
        public Ticket()
        {

        }
        //Constructor 2
        public Ticket(double ticketPrice, string ticketDescription, string ticketType, Seat ticketSeat)
        {
            TicketPrice = ticketPrice;
            TicketDescription = ticketDescription;
            TicketType = ticketType;
            TicketSeat = ticketSeat;
        }
    }
}
