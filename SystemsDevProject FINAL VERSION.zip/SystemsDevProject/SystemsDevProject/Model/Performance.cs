﻿using System;
using System.Collections.Generic;

namespace SystemsDevProject
{
    public class Performance
    {
        //enable getter and setter
        public int PerformanceID { get; set; }
        public DateTime PerformanceDate { get; set; }
        public string PerformanceStatus { get; set; }
        public List<Band> PerformanceBands { get; set; }

        //Constructor 1
        public Performance()
        {

        }
        //Constructor 2
        public Performance(DateTime performanceDate, string performanceStatus)
        {
            PerformanceDate = performanceDate;
            PerformanceStatus = performanceStatus;
            PerformanceBands = new List<Band>();
        }
    }
}