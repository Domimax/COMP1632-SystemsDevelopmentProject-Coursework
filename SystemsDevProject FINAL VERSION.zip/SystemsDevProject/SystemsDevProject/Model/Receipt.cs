﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SystemsDevProject.Model
{
    class Receipt
    {
        //enable getter and setter
        public DateTime dateOfAttendance { get; set; }
        public string performanceName { get; set; }
        public double price { get; set; }
        public string SeatNumber { get; set; }
        public int receiptNumber = 1;

        //Constructor 1
        public Receipt()
        {

        }
        //Constructor 2
        public Receipt(DateTime date, string seatnumber, double a, string performance)
        {
            date = dateOfAttendance;
            performanceName = performance;
            SeatNumber = seatnumber;
            a = price;
        }
        //Method to write the booking info into a text file
        public void printReceipt()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            File.Create(path);
            StreamWriter writer = new StreamWriter(path);
            writer.Write("This is confirmation of your booking. Keep this document in a safe place" + "\r\n" + "Performance name: " + performanceName
                + "\r\n" + "Date of Performance: " + dateOfAttendance + "\r\n" + "Number of tickets: " + SeatNumber +
                "\r\n" + "Total price: " + price + "\r\n" + "Receipt number: " + receiptNumber);
            receiptNumber++;

        }
    }
}

