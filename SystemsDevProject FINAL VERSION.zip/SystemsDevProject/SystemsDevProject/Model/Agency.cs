﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemsDevProject.Model
{
    public class Agency : User
    {
        public int AgencyID { get; set; }
        public string AgencyName { get; set; }

        //Constructor 1
        public Agency(int agencyID, string agencyName)
        {
            AgencyID = agencyID;
            AgencyName = agencyName;
        }
        //Constructor 2
        public Agency(string agencyName)
        {
            AgencyName = agencyName;
        }
        //Constructor 3
        public Agency()
        {

        }
    }
}
