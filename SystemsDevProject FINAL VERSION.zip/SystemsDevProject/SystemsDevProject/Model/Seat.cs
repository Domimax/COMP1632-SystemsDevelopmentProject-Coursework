﻿namespace SystemsDevProject
{
    public class Seat
    {
        //enable getter and setter
        public int SeatID { get; set; }
        public int SeatNumber { get; set; }
        public bool Occupied { get; set; }

        //Constructor 1
        public Seat()
        {

        }
        //Constructor 2
        public Seat(int seatNumber, bool occupied)
        {
            SeatNumber = seatNumber;
            Occupied = occupied;
        }
    }
}